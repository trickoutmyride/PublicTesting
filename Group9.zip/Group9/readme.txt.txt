To Run Server:
(Windows)
start cmd.exe
Browse to directory with server .jar file
Enter the following in cmd.exe
java -jar Group9Server.jar [port]
	where [port] is the port you want to host on minus brackets
example: java -jar Group9Server.jar 8080


To Run Client:
(Windows) 