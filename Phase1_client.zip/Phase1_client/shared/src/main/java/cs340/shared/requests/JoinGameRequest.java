package cs340.shared.requests;

/**
 * Created by Mark on 2/4/2018.
 */

public class JoinGameRequest {
}
