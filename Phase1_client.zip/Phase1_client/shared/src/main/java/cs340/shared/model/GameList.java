package cs340.shared.model;

import java.util.ArrayList;

public class GameList {
	/* Fields */
	private ArrayList<Game> games;

	/* Methods */
	public ArrayList<Game> getGames() {
		return games;
	}

	public void setGames(ArrayList<Game> games) {
		this.games = games;
	}
}
