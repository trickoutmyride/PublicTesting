package cs340.shared;

import com.google.gson.Gson;

/**
 * Created by sam on 2/8/18.
 */

public class Main {

    public static void main(String[] args){
        Gson gson = new Gson();
    }
}
