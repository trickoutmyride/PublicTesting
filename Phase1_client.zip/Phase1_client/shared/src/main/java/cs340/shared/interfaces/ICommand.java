package cs340.shared.interfaces;

public interface ICommand {
    public void execute();
}
