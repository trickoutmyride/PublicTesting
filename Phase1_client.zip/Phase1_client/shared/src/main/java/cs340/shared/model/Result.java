package cs340.shared.model;

/**
 * Created by Mark on 1/31/2018.
 */

public class Result {
}
