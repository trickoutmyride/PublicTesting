package cs340.shared.services;

import cs340.shared.interfaces.IClient;

/**
 * Executes functions based on ClientCommands processed by CommandProcessor coming from the server.
 * I need things to fill this with.
 */
public class ClientFacade implements IClient {
	public void createGame(Object request) {

	}

	public void joinGame(Object request) {

	}

	public void login(Object request) {

	}

	public void register(Object request) {

	}

	public void startGame(Object request) {

	}

	public void error(Object request) {

	}
}